To run code, just execute in editor. Will perform training of NN with 500 epochs and minibatch size of 500. 
Takes a while and outputs some run control and pictures at the end.