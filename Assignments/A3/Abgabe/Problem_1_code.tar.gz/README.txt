Assignment 3 Lukas Nies

Problem 1: 

	- Note: For some reason, my code is pretty slow for the whole problem (even though using matrix algebra)
			so please be patient in executing it...
			
	+	Problem_1.1.py: Just execute in editor, performs grid search, outputs parameters with best performance

	+	Problem_1.2.py: Just execute in editor, outputs a plot in extra window after finished, prints loop control
						while executing the gradient descent ( For K=3000 takes maybe 10 mins... )
	
	+	Problem_1.3.py: Just execute in editor, outputs a plot in extra window after finished, prints loop control
						while executing the gradient descent ( For K=3000 takes maybe 10 mins... )

Problem 2:


Problem 3


Problem 4


Problem 5


Problem 6
