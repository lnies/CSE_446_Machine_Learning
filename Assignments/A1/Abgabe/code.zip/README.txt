Assigment 1 Problem 4

To run the code simply run the python code 

./kmeans_template.py

The online output will give some information about the current number of loops and the labels array.

NOTE: 

In 1 out of 5 runs the code crashes and returning an error that it ran into "NaN" or "inf" values, 
I was not able to solve this bug (sorry). But in 4/5 the code runs just fine and gives
the expected results. Just run it multiple times if you get that error.